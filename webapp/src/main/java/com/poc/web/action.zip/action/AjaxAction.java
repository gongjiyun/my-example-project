/**
This class add by Administrator
*/
package com.poc.web.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;


public class AjaxAction extends BaseAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public String list() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		
		String searchCon = request.getParameter("name");
		System.out.println("ajax request send : " + searchCon);
		
		response.setContentType("text/xml;charset=UTF-8");
		response.setHeader("Cache-Control", "no-cache");
		
		PrintWriter pw = response.getWriter();
		String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
				"<name>test1</name>";
		pw.write(xml);
		pw.flush();
		return null;
	}

}
