package com.poc.web.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ParameterAware;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;

/**
 * Target       : 
 * Created By   : jiyun
 * Created Date : May 5, 2011
 * Version      :
 * Remarks      :
 */
public class BaseAction extends ActionSupport implements ParameterAware, ServletRequestAware, ServletResponseAware, SessionAware{
	/** ser
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Map sessionMap=null;
	private HttpServletRequest request=null;
	private HttpServletResponse response=null;
	private Map parameterMap=null;
	public String SUCCESS="success";
	public String FAILURE="failure";
	

	public Map getSessionMap() {
		return sessionMap;
	}
	public HttpServletRequest getRequest() {
		return request;
	}
	public HttpServletResponse getResponse() {
		return response;
	}

	public void setServletRequest(HttpServletRequest arg0) {
		this.request=arg0;
	}
	public void setServletResponse(HttpServletResponse arg0) {
		this.response=arg0;
	}
	public void setSession(Map arg0) {
		this.sessionMap=arg0;
	}

	public Map getParameterMap() {
		return parameterMap;
	}

	public void setParameters(Map arg0) {
		this.parameterMap=arg0;
	}
}
