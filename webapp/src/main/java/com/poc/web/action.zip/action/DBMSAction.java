package com.poc.web.action;

import java.util.List;

import com.opensymphony.xwork2.Action;
import com.poc.common.vo.TableVO;
import com.poc.service.DBMSService;

public class DBMSAction extends BaseAction {
	private DBMSService dbmsService;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String tableName;
	public String input(){
		List<String> tableList = dbmsService.searchAllTables();
		getRequest().setAttribute("tableList", tableList);
		return Action.INPUT;
	}
	
	public String list(){
		input();
		if(this.tableName!=null){
			TableVO table = dbmsService.getTableInfo(tableName);
			getRequest().setAttribute("result", table);
		}
		return Action.INPUT;
	}

	public DBMSService getDbmsService() {
		return dbmsService;
	}

	public void setDbmsService(DBMSService dbmsService) {
		this.dbmsService = dbmsService;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	
}
