/**
This class add by jiyun
*/
package com.poc.web.action;

import org.apache.log4j.Logger;


public class UIAction extends BaseAction {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Logger logger=Logger.getLogger(UIAction.class);
	public String input(){
		logger.debug("test page techonic.");
		return INPUT;
	}

}
