/**
This class add by jiyun
*/
package com.poc.web.action.file;

import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.struts2.ServletActionContext;
import org.w3c.dom.Document;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.poc.web.action.BaseAction;

public class DownloadReportAction extends BaseAction{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public String downloadPdf(){
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		
		try{
			DocumentBuilderFactory factory =  DocumentBuilderFactory.newInstance();
			DocumentBuilder db = factory.newDocumentBuilder();

			InputStream is =DownloadReportAction.class.getClassLoader().getResourceAsStream("test.html");
			Document doc = db.parse(is);
			
			response.setContentType("application/pdf");
			response.setHeader("content-disposition","inline;filename=xhtml.pdf");
			OutputStream os = response.getOutputStream();
			
			ITextRenderer renderer = new ITextRenderer();
	        renderer.setDocument(doc, null);
	        renderer.layout();
	        renderer.createPDF(os);
	        os.flush();
	        os.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return null;
	}
	public static void main(String[] args) throws Exception{		
	}

}
