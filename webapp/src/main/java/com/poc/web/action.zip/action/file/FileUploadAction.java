/**
This class add by Administrator
*/
package com.poc.web.action.file;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import javax.servlet.ServletContext;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.poc.service.UploadService;
import com.poc.web.action.BaseAction;

public class FileUploadAction extends BaseAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Logger logger=Logger.getLogger(FileUploadAction.class);
	private UploadService uploadService;
	private File upload;
	private String uploadFileName;
	private String uploadContentType;
	
	public String input(){
		
		return INPUT;
	}
	public String upload(){
		ServletContext application = ServletActionContext.getRequest().getSession().getServletContext();  
		try{
			//test interceptor
			System.out.println("interceptor");
			uploadService.loadData();
			
			System.out.println("uploadService:"  +  uploadService);
			
			System.out.println("--------------------");
			//uploadServiceImpl = (UploadServiceImpl) WebApplicationContextUtils.getWebApplicationContext(application).getBean("uploadServiceImpl");
			//uploadServiceImpl.upload();

			System.out.println("File : " + this.getUpload());
			System.out.println("File name : " + this.getUploadFileName());
			FileInputStream fin = new FileInputStream(this.getUpload());
			
			if(fin!=null){
				File saveFile = new File(File.separator + "workspace" + File.separator + this.getUploadFileName());
				FileOutputStream fout = new FileOutputStream(saveFile);
				byte[] bt = new byte[1024];
				int len = 0;
				while((len = fin.read(bt))>=0){
					fout.write(bt, 0, len);
				}
				fout.flush();
				fout.close();
			}
			
			fin.close();
		}catch (Exception e) {
			addActionError(e.getMessage());
		}
		return SUCCESS;
	}

	public File getUpload() {
		return upload;
	}
	public void setUpload(File upload) {
		this.upload = upload;
	}
	public String getUploadFileName() {
		return uploadFileName;
	}
	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}
	public String getUploadContentType() {
		return uploadContentType;
	}
	public void setUploadContentType(String uploadContentType) {
		this.uploadContentType = uploadContentType;
	}
	public UploadService getUploadService() {
		return uploadService;
	}
	public void setUploadService(UploadService uploadService) {
		this.uploadService = uploadService;
	}
}
