package com.poc.web.action.login;

import java.util.Enumeration;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.opensymphony.xwork2.ActionContext;
import com.poc.common.entities.User;
import com.poc.service.PersonService;
import com.poc.service.UserService;
import com.poc.web.action.BaseAction;
import com.poc.web.constant.IConstant;

/**
 * Target       : 
 * Created By   : jiyun
 * Created Date : 2011-5-6
 * Version      :
 * Remarks      :
 */
public class LoginAction extends BaseAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Logger logger=Logger.getLogger(LoginAction.class);
	@Autowired
	@Qualifier("userService")
	private UserService userService;
	@Autowired
	@Qualifier("personService")
	private PersonService personService;
	
	public String testID="testID";
	
	private String loginId;
	private String userName;
	private String password;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String init(){
		try {
			HttpServletRequest request=ServletActionContext.getRequest();
			HttpServletResponse response=ServletActionContext.getResponse();		
			//List allPersons = personService.getAllPersons();
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
		}
		return "login";
	}
	
	public String logout(){
		try {
			HttpServletRequest request=ServletActionContext.getRequest();
			HttpServletResponse response=ServletActionContext.getResponse();		
			
			HttpSession session = request.getSession();
			if(session!=null){
				Enumeration<String> em = session.getAttributeNames();
				while(em.hasMoreElements()){
					String name = em.nextElement().toString();
					session.removeAttribute(name);
				}
				session.invalidate();
			}
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
		}
		return "login";
	}

	public String login(){
		HttpServletRequest request=ServletActionContext.getRequest();
		logger.debug("Login id : "+ loginId);
		try {
			System.out.println("##################test ejb ###################");
			this.testEJB();
			
			System.out.println("##################test aop ###################");
			
			User user=userService.getUserById(loginId);
			if(user==null){
				addActionError("User not exist");
				return ERROR;
			}else{				
				request.getSession().setAttribute(IConstant.SESSION_KEY_USER, user);
				ActionContext.getContext().getSession().put(IConstant.SESSION_KEY_USER, user);				
			}
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(e.getMessage());
			return ERROR;
		}
		return INPUT;
	}
	public UserService getUserService() {
		return userService;
	}
	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public PersonService getPersonService() {
		return personService;
	}
	public void setPersonService(PersonService personService) {
		this.personService = personService;
	}
	
	public String getMyId(){
		return "1";
	}
	
	public String home(){
		
		logger.debug("go home page.");
		try{
			logger.debug("test active mq start");
			HttpSession httpSession = this.getRequest().getSession();
			ApplicationContext appCtx = WebApplicationContextUtils.getWebApplicationContext(httpSession.getServletContext());
			JmsTemplate jms = (JmsTemplate) appCtx.getBean("jmsTemplate");
			jms.send(new MessageCreator() {
				public Message createMessage(Session session) throws JMSException {
					System.out.println("create message");
					TextMessage message = session
							.createTextMessage("hello jms template");
					return message;
				}
			});
			logger.debug("test active mq end");
		}catch (Exception e) {
			e.printStackTrace();
			addActionError("test MQ JMS : " + e.getMessage());
		}

		
		return "home";
	}
	
	public void testEJB() throws Exception{
		try{
			System.out.println("testEJB start");
			System.out.println("testEJB end");
		}catch(Exception e){
			e.printStackTrace();
			addActionError(e.getMessage());
		}
	}
	
}
