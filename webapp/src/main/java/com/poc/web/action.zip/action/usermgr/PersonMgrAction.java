package com.poc.web.action.usermgr;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.poc.common.entities.PersonProfile;
import com.poc.service.PersonService;
import com.poc.utils.util.UUIDGenerator;
import com.poc.web.action.BaseAction;

public class PersonMgrAction extends BaseAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private PersonService personService;
	private PersonProfile person;
	private static Logger logger=Logger.getLogger(PersonMgrAction.class);
	public PersonService getPersonService() {
		return personService;
	}
	public void setPersonService(PersonService personService) {
		this.personService = personService;
	}
	
	public String list(){
		try{
			HttpServletRequest request=ServletActionContext.getRequest();
			List allPersons = personService.getAllPersons();
			request.setAttribute("allPersons", allPersons);
			return INPUT;
		}catch(Exception e){
			e.printStackTrace();
			addActionError(e.getMessage());
		}
		return ERROR;
	}
	
	public String add(){
		try{
			HttpServletRequest request=ServletActionContext.getRequest();
			person.setId(UUIDGenerator.getInstance().uuid());
			personService.insertPerson(person);
			list();
		}catch(Exception e){
			e.printStackTrace();
		}
		return INPUT;
	}
	
	public String update(){
		try{
			HttpServletRequest request=ServletActionContext.getRequest();
			personService.updatePerson(person);
			list();
		}catch(Exception e){
			e.printStackTrace();
		}
		return INPUT;
	}
	
	public String delete(){
		try{
			personService.deletePerson(person.getId());
			list();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return INPUT;
	}
	public PersonProfile getPerson() {
		return person;
	}
	public void setPerson(PersonProfile person) {
		this.person = person;
	}
	
}
